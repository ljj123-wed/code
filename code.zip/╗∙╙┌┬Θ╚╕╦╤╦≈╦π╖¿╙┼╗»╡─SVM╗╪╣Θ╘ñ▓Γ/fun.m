%% ��Ӧ�Ⱥ������Իع�mse��Ϊ��Ӧ��ֵ
function [fitness] = fun(x,TS,TSX)
    cmd = ['-c ', num2str(x(1)), ' -g ', num2str(x(2)) , ' -s 3 -p 0.01'];
    model = libsvmtrain(TS,TSX,cmd);
   [predict,mse,~] = libsvmpredict(TS,TSX,model);
    if size(mse,1) == 0
        fitness = 1;
    else
        fitness = mse(2);
    end
end