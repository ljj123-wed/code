function NewChrom = xovmp(OldChrom, Px, Npt, Rs)

%%  多点交叉
%       This function takes a matrix OldChrom containing the binary
%       representation of the individuals in the current population,
%       applies crossover to consecutive pairs of individuals with
%       probability Px and returns the resulting population.
%
%       Npt indicates how many crossover points to use (1 or 2, zero
%       indicates shuffle crossover).
%       Rs indicates whether or not to force the production of
%       offspring different from their parents.
% Identify the population size (Nind) and the chromosome length (Lind)

%%  一致性检查
[Nind, Lind] = size(OldChrom);

if Lind < 2
    NewChrom = OldChrom;
    return
end

if nargin < 4
    Rs = 0;
end

if nargin < 3
    Npt = 0;
    Rs = 0;
end

if nargin < 2
    Px = 0.7;
    Npt = 0;
    Rs = 0;
end

if isnan(Px)
    Px = 0.7;
end

if isnan(Npt)
    Npt = 0;
end

if isnan(Rs)
    Rs = 0;
end

if isempty(Px)
    Px = 0.7;
end

if isempty(Npt)
    Npt = 0;
end

if isempty(Rs)
    Rs = 0;
end

Xops = floor(Nind / 2);
DoCross = rand(Xops, 1) < Px;
odd = 1: 2: Nind - 1;
even = 2: 2: Nind;

%%  计算每对染色体的有效长度
Mask = ~Rs | (OldChrom(odd, :) ~= OldChrom(even, :));
Mask = cumsum(Mask')';

%%  根据有效长度和 Px 计算每对个体的交叉站点（两个相等的交叉站点意味着没有交叉）
xsites(:, 1) = Mask(:, Lind);
if Npt >= 2
    xsites(:, 1) = ceil(xsites(:, 1) .* rand(Xops, 1));
end

xsites(:, 2) = rem(xsites + ceil((Mask(:, Lind) - 1) .* rand(Xops, 1)) ...
                                .* DoCross - 1, Mask(:, Lind)) + 1;

%%  以 0-1 掩码表示跨站点
Mask = (xsites(:, ones(1, Lind)) < Mask) == ...
                        (xsites(:, 2 * ones(1, Lind)) < Mask);

if ~Npt
    shuff = rand(Lind, Xops);
    [~, shuff] = sort(shuff);
    for i = 1: Xops
        OldChrom(odd(i), :) = OldChrom(odd(i), shuff(:, i));
        OldChrom(even(i), :) = OldChrom(even(i), shuff(:, i));
    end
end

%%  执行交叉
NewChrom(odd, :) = (OldChrom(odd, :) .* Mask) + (OldChrom(even, :) .* (~Mask));
NewChrom(even, :) = (OldChrom(odd, :) .* (~Mask)) + (OldChrom(even, :) .* Mask);

%%  如果个体数为奇数，最后一个个体不能交配，但必须包含在新种群中
if rem(Nind, 2)
  NewChrom(Nind, :) = OldChrom(Nind, :);
end

if ~Npt
    [~, unshuff] = sort(shuff);
    for i = 1: Xops
        NewChrom(odd(i), :) = NewChrom(odd(i), unshuff(:, i));
        NewChrom(even(i), :) = NewChrom(even(i), unshuff(:, i));
    end
end
