function MatOut = rep(MatIn, REPN)

%%  复制矩阵
% This function replicates a matrix in both dimensions. 
% Input parameters:
%   MatIn    - Input Matrix (before replicating)
%
%   REPN     - Vector of 2 numbers, how many replications in each dimension
%              REPN(1): replicate vertically
%              REPN(2): replicate horizontally
%
%              Example:
%
%              MatIn = [1 2 3]
%              REPN = [1 2]: MatOut = [1 2 3 1 2 3]
%              REPN = [2 1]: MatOut = [1 2 3;
%                                      1 2 3]
%              REPN = [3 2]: MatOut = [1 2 3 1 2 3;
%                                      1 2 3 1 2 3;
%                                      1 2 3 1 2 3]
% Output parameter:
%   MatOut   - Output Matrix (after replicating)

%%  获取输入矩阵的大小
[N_D, N_L] = size(MatIn);

%%  计算
Ind_D = rem(0: REPN(1) * N_D - 1, N_D) + 1;
Ind_L = rem(0: REPN(2) * N_L - 1, N_L) + 1;

%%  创建输出矩阵
MatOut = MatIn(Ind_D, Ind_L);