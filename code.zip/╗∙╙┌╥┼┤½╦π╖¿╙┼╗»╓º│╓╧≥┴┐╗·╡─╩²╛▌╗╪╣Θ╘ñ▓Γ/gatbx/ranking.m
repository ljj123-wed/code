function FitnV = ranking(ObjV, RFun, SUBPOP)

%%  基于排名的健身分配
% This function performs ranking of individuals.
%
% This function ranks individuals represented by their associated
% cost, to be *minimized*, and returns a column vector FitnV
% containing the corresponding individual fitnesses. For multiple
% subpopulations the ranking is performed separately for each
% subpopulation.
%
% Input parameters:
%    ObjV      - Column vector containing the objective values of the
%                individuals in the current population (cost values).
%    RFun      - (optional) If RFun is a scalar in [1, 2] linear ranking is
%                assumed and the scalar indicates the selective pressure.
%                If RFun is a 2 element vector:
%                RFun(1): SP - scalar indicating the selective pressure
%                RFun(2): RM - ranking method
%                         RM = 0: linear ranking
%                         RM = 1: non-linear ranking
%                If RFun is a vector with length(Rfun) > 2 it contains
%                the fitness to be assigned to each rank. It should have
%                the same length as ObjV. Usually RFun is monotonously
%                increasing.
%                If RFun is omitted or NaN, linear ranking
%                and a selective pressure of 2 are assumed.
%    SUBPOP    - (optional) Number of subpopulations
%                if omitted or NaN, 1 subpopulation is assumed
% Output parameters:
%    FitnV     - Column vector containing the fitness values of the
%                individuals in the current population.


%%  确定向量大小（Nind）
   [Nind, ~] = size(ObjV);

   if nargin < 2
       RFun = [];
   end

   if nargin > 1
       if isnan(RFun)
           RFun = [];
       end
   end

   if numel(RFun) == 2

      if RFun(2) == 1
          NonLin = 1;
      elseif RFun(2) == 0
          NonLin = 0;
      else
          error('Parameter for ranking method must be 0 or 1');
      end

      RFun = RFun(1);

      if isnan(RFun)
          RFun = 2;
      end

   elseif numel(RFun) > 2

      if numel(RFun) ~= Nind
          error('ObjV and RFun disagree');
      end

   end

   if nargin < 3
       SUBPOP = 1;
   end

   if nargin > 2
      if isempty(SUBPOP)
          SUBPOP = 1;
      elseif isnan(SUBPOP)
          SUBPOP = 1;
      elseif length(SUBPOP) ~= 1
          error('SUBPOP must be a scalar');
      end
   end

   if (Nind / SUBPOP) ~= fix(Nind / SUBPOP)
       error('ObjV and SUBPOP disagree');
   end

   % 计算每个亚群的个体数量
   Nind = Nind / SUBPOP;
   
% 检查排名功能，必要时使用默认值
   if isempty(RFun)

   % 线性排序与选择压力 2
   RFun = 2 * (0: Nind-1)' / (Nind - 1);
   elseif numel(RFun) == 1
      if NonLin == 1

         % 非线性排名
         if RFun(1) < 1
             error('Selective pressure must be greater than 1');
         elseif RFun(1) > Nind-2
             error('Selective pressure too big');
         end

         Root1 = roots([RFun(1) - Nind, RFun(1) * ones(1, Nind - 1)]);
         RFun = (abs(Root1(1)) * ones(Nind,1)) .^ (0: Nind - 1)';
         RFun = RFun / sum(RFun) * Nind;

      else
         % SP 介于 1 和 2 之间的线性排名
         if (RFun(1) < 1 || RFun(1) > 2)
            error('Selective pressure for linear ranking must be between 1 and 2');
         end
         RFun = 2 - RFun + 2 * (RFun - 1) * (0: Nind - 1)' / (Nind - 1);

      end
   end

   FitnV = [];

% 循环遍历所有亚群
for irun = 1: SUBPOP
   % 复制实际亚群的客观值
      ObjVSub = ObjV((irun - 1) * Nind + 1 : irun * Nind);
   % Sort 不按要求处理 NaN 值
      NaNix = isnan(ObjVSub);
      Validix = find(~NaNix);
   % 只对数值进行排序（越小越好）。
      [~, ix] = sort(-ObjVSub(Validix));

   % 建立索引向量假设 NaN 比数字差,包括Inf！
      ix = [find(NaNix); Validix(ix)];

   % 获得 ObjV 的排序版本
      Sorted = ObjVSub(ix);

   % 根据 RFun 分配适应度
      i = 1;
      FitnVSub = zeros(Nind, 1);
      for j = [find(Sorted(1 : Nind - 1) ~= Sorted(2: Nind)); Nind]'
         FitnVSub(i: j) = sum(RFun(i: j)) * ones(j - i + 1, 1) / (j - i + 1);
         i = j + 1;
      end

   % 返回未排序的向量。
      [~, uix] = sort(ix);
      FitnVSub = FitnVSub(uix);

   % 将 FitnVSub 添加到 FitnV
      FitnV = [FitnV; FitnVSub];
end