function NewChrIx = sus(FitnV, Nsel)

%%  随机通用抽样
% This function performs selection with STOCHASTIC UNIVERSAL SAMPLING.
% Input parameters:
%    FitnV     - Column vector containing the fitness values of the
%                individuals in the population.
%    Nsel      - number of individuals to be selected
%
% Output parameters:
%    NewChrIx  - column vector containing the indexes of the selected
%                individuals relative to the original population, shuffled.
%                The new population, ready for mating, can be obtained
%                by calculating OldChrom(NewChrIx,:).

%%  确定种群规模 (Nind)
Nind = size(FitnV, 1);

%%  执行随机通用抽样
cumfit = cumsum(FitnV);
trials = cumfit(Nind) / Nsel * (rand + (0: Nsel - 1)');
Mf = cumfit(:, ones(1, Nsel));
Mt = trials(:, ones(1, Nind))';
[NewChrIx, ~] = find(Mt < Mf & [ zeros(1, Nsel); Mf(1: Nind - 1, :) ] <= Mt);

%%  打乱种群
[~, shuf] = sort(rand(Nsel, 1));
NewChrIx = NewChrIx(shuf);